<script setup>
import CarList from '../components/cars/CarList.vue'
import CarFilter from '../components/cars/CarFilter.vue'
import CarSearch from '../components/cars/CarSearch.vue'
</script>

<template>

</template>

<style scoped>

</style>