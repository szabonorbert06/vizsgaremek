<script setup>
import BookingForm from '../components/booking/BookingForm.vue'
</script>

<template>

</template>

<style scoped>

</style>