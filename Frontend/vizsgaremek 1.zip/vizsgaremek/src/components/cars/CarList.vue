<script setup>
import CarCard from './CarCard.vue'
</script>

<template>

</template>

<style scoped>

</style>