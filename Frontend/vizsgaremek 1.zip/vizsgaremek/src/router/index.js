import { createRouter, createWebHistory } from 'vue-router'

import HomeView from '../views/HomeView.vue'
import CarsView from '../views/CarsView.vue'
import CarDetailsView from '../views/CarDetailsView.vue'
import BookingView from '../views/BookingView.vue'
import LoginView from '../views/LoginView.vue'

const routes = [
    {
        path: '/',
        component: HomeView
    },
    {
        path: '/cars',
        component: CarsView
    },
    {
        path: '/cars/:id',
        component: CarDetailsView
    },
    {
        path: '/booking',
        component: BookingView
    },
    {
        path: '/login',
        component: LoginView
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router